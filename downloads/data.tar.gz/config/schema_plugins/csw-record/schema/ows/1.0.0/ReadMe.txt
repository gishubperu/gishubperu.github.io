This set of XML Schema Documents for the OpenGIS Web Services (OWS) 
Implementation Specification version 1.0.0 [OGC 05-008] has been 
edited to reflect the corrigendum to that document that is based 
on the change requests: 
OGC 05-059r2 "Make element and type names public"
OGC 05-067r1 "Change ows namespace identifier URL to http://www.opengis.net/ows"
OGC 05-068r1 "Store xlinks.xsd file at a fixed location"
OGC 05-080r1 "Store OGC XML schema documents in one place"
OGC 05-081r2 "Change to use relative paths"
OGC 05-105 "Remove description and copyright tags from XML schema documents"

Arliss Whiteside, 2005-11-22

