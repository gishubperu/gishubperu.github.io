ISO(c) - ISO/TS 19139:2007 resources
------------------------------------------------------------------------------

ISO/TS 19139:2007 resources are XML Files provided with the XML
Schema Implementations defined in ISO/TS 19139-2. Those resources are:
- Catalogues of Codelist, Units of measure (uom) and Coordinate Reference
  Systems (CRS)
- sample XML

-------------------------------------------------------------------------------

2012-07-13 Nicolas Lesage on behalf of the ISO/TC 211 XML Maintenance Group
	* Update of Readme.txt file
	* Use of absolute schema locations
	* Adoption of W3C Implementation of XLink:

	Validation: XML Files have been validated with XML Spy 2010 Rel. 2 (MSXML 6.0)


No history...
